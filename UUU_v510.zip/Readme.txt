Universal Unreal Engine 5 Unlocker (UUU) v5
==========================================================

UUU Version: v5.1.0

----------------------------------------------------------------

   For updates and support: https://www.patreon.com/Otis_Inf
   For documentation, please visit: https://opm.fransbouma.com/uuuv5.htm

----------------------------------------------------------------

IMPORTANT: For games using Unreal Engine 5.1 or higher. 

Changelog
==============
v5.1.0:
	ADDED: Reworked the postprocessing tab, there are now over 96 settings to tweak, complete with presets (I included a couple to get you started). I've included all
	       settings from the Unreal Engine post-processing volume that made sense. It greatly enhances tweakability of games. Please see the updated documentation at
		   https://opm.fransbouma.com/uuuv5.htm for details. 
v5.0.8:
	ADDED: Added the Light's Shadow Resolution Scale slider back. It was removed early in 5.0 as the setting didn't seem to do anything but 
	       that was a mistake, it does affect light resolution.
v5.0.7:
	FIXED: UObject::ProcessEvent used a pattern which could match with the wrong function, causing lights / camera enable to crash the game. 
	       This happens with UE5.2+ games, like Robocop, Lords of the Fallen and others.
    FIXED: Bug in the UUU black bars removal code actually introduced constrained aspect ratio limitation in some games, e.g. Lords of the Fallen.
v5.0.6: 
	FIXED: The FoV and camera coordinates weren't reported correctly in the IGCSConnector
	FIXED: Dumping cvars could crash due to illegal utf8 characters being written to the json file.
	FIXED: The quaternion to roll angle calculation didn't negate the value so API calls to step the camera in a situation where the camera had any tilt caused misalignment. E.g. focusing in 
	       IGCS DoF with the UUU v5 was difficult if there was any tilt/roll involved. 
	CHANGED: Switched the light intensity units to Lumens for new lights and changed the default max from 15000 to 1500. This will give brighter lights even in worlds with strong sunlight
	         or Lumen lit environments.
v5.0.5:
	ADDED: Added a previous/next light button pair at the top of the Light editor window to cycle through the lights without the necessity to go back to the main light list.
	ADDED: Better HUD toggle in case the existing one doesn't work properly.
v5.0.4:
	FIXED: On modular builds and some other games where the ConsoleManager wasn't found, the UUU would crash as it didn't properly handle the situation 
           when the console manager wasn't found. 
v5.0.3:
	ADDED: Cvars are now also dumped in a .json file, additionally to the .txt file the UUU already wrote to.
	ADDED: Readonly CVars and commands are now unlocked without dumping them to a file.
	ADDED: More blackbar removal code (Now works in e.g. Jusant)
v5.0.2:
	FIXED: Camera movement shake strength was affected by how high the movement speed was set. This isn't the case anymore. 
	ADDED: On the Available Features tab, you can now click 'Dump CVars' (when supported by the game) and it'll dump a file with all the cvars/commands you can 
	       use on the console, with the help text and the type + current value of the variable. This file is placed next to the objects dump file
		   you can create on the same tab, using the filename "UUU_CVarsDump.txt"
v5.0.1: 
	ADDED: Ability to configure which gamepad trigger is used for moving camera up/down
	ADDED: Ability to configure which gamepad stick is used for rotating/moving the camera (for left-handed users).
	ADDED: Keybinding for appending a new node after the active node on the current path 
	ADDED: Keybinding for deleting the current path
	ADDED: Keybinding for deleting the active node on the current path
	ADDED: Shift / Shift+Ctrl are now usable on the sliders to have them move slower and even more slower
	ADDED: The mousewheel can now be used on the sliders to move the value. Using Shift or Shift+Ctrl makes the slider move slower and even slower.
v5.0.0: First public v5 release. 

How to use
===========
Please do the following: Run the game and then the IGCSClient.exe. If the game runs as administrator, you have to run the 
IGCSClient.exe also as administrator, but this isn't required. In the IGCSClient, click 'Select' to select the game process to inject the dll into. 
This is usually a gamename-win64-shipping.exe process. When you've selected the game to inject the dll into, click the 'Inject dll' button. 

Don't close the client, it's your tool to the camera for configuration
There's a Help tab in the GUI. Please read it. 

Camera control device
========================
In the configuration tab of the IGCS Client, you can specify what to use for controlling the camera: 
controller, keyboard+mouse, or both. The device you pick is blocked from giving input to the game, 
if you press 'Numpad .' (On by default). 

About custom lights
====================
If the game supports custom lights, you can create new lights on the lights tab (or use one of the keyboard shortcuts). 
By clicking the pencil button you can open the editor of a created light. When the editor is open, clicking the pencil button 
of another light will open that ligth in the editor instead. Changes you make are taking effect immediately. 

The light editor has several numeric textboxes like the x/y/z position. To change the values in these, click inside the box and
use your mousewheel to change value. Use shift + mousewheel to take bigger steps and ctrl + mousewheel to take small steps. 

Sometimes the engine will glitch and stop updating a light, e.g. when it's attached to the camera. To recover from this, switch the light
off and on again (yes, really) and it'll continue working. I don't know what the reason is for this. 

NOTE: when you're done with the lights for a scene, delete them. Especially newer engines can hang when loading a new level when there are 
existing lights. The tools have a checker which runs every 10 seconds but this isn't 100% fail safe. 

NOTE: not all features work in older engines. If you think it should work but it doesn't, please let me know and I'll have a look. Lights in UE4
went through a lot of changes starting in UE v4.18+, so if you're playing a game that's older than that, expect a lot of the features to have little or no effect. 

About hotsampling support
==========================
To take screenshots at higher resolutions than your regular gaming resolution, run the game in windowed mode. 
To get rid of the window border, on the Hotsampling tab, click 'Fake fullscreen'. 
To switch to a high resolution, select the resolution and aspect ratio you want from the tree on the Hotsampling tab and click 'Set'. 
You can also select one from the list of previous used resolutions if you switch between a given set of resolutions frequently. 
If the resolution fits your monitor, the game will add a border, you have to click 'Set' again to get rid of it. 

The IGCS client will resize the game window to the requested resolution and the game will resize the game 
framebuffer accordingly, allowing you to take a shot at a high resolution. To go back to your regular gaming 
resolution, simply click the 'Fake fullscreen' button again.

About the multiple timestop systems.
=====================================
The UUU has two ways to pause the game: using the normal UWorld::IsPaused hack, (Numpad 0), and one using the slomo command code, (Page down).
You can use either one, if they're both found of course. Numpad 0 is a hard-pause which could lead to TAA jitter in the scene. You can 
remove that by stepping down the AA a bit, using: r.postprocessaaquality 2 in the console. To set it back, use r.postprocessaaquality 6.
The downside of that is that cutscenes might play on and the lower quality AA might remove some effects. 

The slomo based pause using Page Down doesn't suffer from TAA jitter, and can pause most, if not all, cutscenes as well (except audio in some
situations). In general, if the latter is supported, you should use the slomo based pause. 

About invulnerability
======================
The UUU has a simple invulernability setting that switches bCanBeDamaged off on your player character. This might not work in most games, 
so try before relying on this in combat scenes. 

About character scaling
========================
The UUU can scale your character in-game's size. Use the Player size slider for that. If you have paused the game, changing this slider doesn't
have an immediate effect; the engine requires user input to make the character change its size. To do that in a paused game: press a directional key 
to move the character or use your controller, and then press the Skip frame button (By default End) to skip a frame. 
You can also use this to hide your character: set the size to 0 and your character is invisible. 

Built-in camera system
=========================
The UUU comes with a built-in sophisticated camera system you can configure yourself using the keybinds in the Configuration tab. You can
select which device you'll use for camera movement (By default both kb/mouse and controller are selected). 

Troubleshooting
===================
This is the UUU version for games using Unreal Engine 5.1 or higher. As Unreal Engine 5.1 is rather new, if you get lots of errors, 
it might very well be the game you're using the UUU v5 with isn't using Unreal Engine 5 but Unreal Engine 4 (or not using Unreal Engine at all!). 
So be sure the game uses Unreal Engine 5 when using this UUU version.

If you get AOB errors when injecting the dll, it might be the engine's code hasn't been fully initialized yet and AOB scanning can't
find it. Simply load a level and try again by pressing CTRL+END. 

The built-in HUD toggle might not work if the HUD is built with a custom HUD system like scaleform. In that case the hud toggle won't hide
the HUD. If that's the case, you might want to try 'showhud 0' (without the quotes) to hide the hud and 'showhud 1' to show it again in the console.
This might not always work, it depends per game. 

In-game console doesn't open
---------------------------------
If the console doesn't open when pressing ~, but all AOBs are found, please do the following:
In the IGCSClient, go to the Configuration tab. In there you can select the key to open the in-game console.
By default the key is '~' or 'Tilde'. Please select a key you don't use in-game and which is available on your
keyboard without using Shift. E.g. if you have a French keyboard (Azerty), you can choose 'Dollar ($)', which means you can 
press the $ key to open the console, which is right above the Enter key on most Azerty keyboards. 

Alternatively, you can choose a US-en keyboard layout, or add a custom key to the ini file of your game, but this might not
always work:

Go to:
c:\users\<your username>\AppData\Local\gamename\Saved\Config\WindowsNoEditor

open Input.ini
Add (pay attention to the empty line!):

[/Script/Engine.InputSettings]
ConsoleKey=Tilde

Save and set to readonly. You can also set it to another key, e.g. K. 

Have fun and create beautiful shots, m'kay? 

Cheers!

Otis_Inf